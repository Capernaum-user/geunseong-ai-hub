# AI 터미널 패널 상태 시스템 — 설치 번들

분할 터미널(Windows Terminal)에서 여러 AI CLI(claude·codex·gemini)를 띄워 놓고 작업할 때,
**각 패널이 "어느 폴더에서 · 무슨 작업을 · 지금 작업중인지"** 를 한눈에 보여주는 도구 모음입니다.

- **Claude 하단 상태줄** — `📁 폴더절대경로 · 🌿 git브랜치 · 모델 · +추가/-삭제 · mm:ss · ctx N% · 🤖 작업라벨`
  - 둘째 줄(Pro/Max): `5h [████░░░░░░] 38% ↻2h13m   7d [█░░░░░░░░░] 19% ↻3d` 사용량 배터리
- **`aistatus` 상태창** — 모든 AI 세션의 🟡작업중 / 🟢대기 / 🔴확인 을 실시간 표로
- **AI 자동 라벨** — 작업을 시작하면 AI가 그 패널 라벨을 스스로 정함(`label "..."`로 수동 변경)
- (선택) **`zwork`** — Zellij 4분할 + 패널 프레임 색 라벨

---

## 요구사항

| 항목 | 필수 | 비고 |
|---|---|---|
| Windows + Windows Terminal | ✅ | |
| PowerShell 7 (`pwsh`) | ✅ | `winget install Microsoft.PowerShell` |
| Claude Code CLI | ✅(상태줄·상태창) | |
| Zellij 0.44+ | 선택 | `winget install zellij` (색 라벨) |
| codex / gemini CLI | 선택 | 상태창에 함께 표시하려면 |

---

## 설치 (원클릭)

이 폴더에서 PowerShell 7로:

```powershell
pwsh -ExecutionPolicy Bypass -File .\install.ps1
```

- 기존 `settings.json` / `$PROFILE` / `CLAUDE.md` 는 **`.bak-paneinstall` 백업 후 병합**합니다(덮어쓰기 아님).
- 경로의 사용자명은 설치 시 `$env:USERPROFILE` 로 **자동 적응**됩니다.
- 옵션: `-NoZellij`(Zellij 건너뜀), `-Uninstall`(되돌리기).

설치되는 것:

| 파일 | 위치 |
|---|---|
| pane-workspace.ps1 | `~\.local\bin\` (→ `$PROFILE`에서 로드) |
| pane-status.ps1 · claude-statusline.ps1 · ai-dashboard.ps1 | `~\.claude\hooks\` |
| hooks + statusLine | `~\.claude\settings.json` (병합) |
| AI 자동 라벨 규칙 | `~\.claude\CLAUDE.md` (추가) |
| (선택) config.kdl · ai4.kdl | `~\AppData\Roaming\Zellij\config\` |

---

## 적용 / 사용

1. **새 PowerShell 창**을 연다(또는 `. $PROFILE`).
2. **새 claude 세션**부터 하단 상태줄 + 자동 라벨이 켜진다(기존 세션엔 미적용).
3. 분할 한 칸에서 상태창을 띄워둔다:

```powershell
aistatus            # 모든 AI 세션 작업중/대기 실시간 표 (Ctrl+C 종료)
wshelp              # 전체 명령 도움말
label "결제 버그"    # 이 패널 작업 라벨 수동 지정
zwork channeldock   # (Zellij) 4분할 색 라벨
```

---

## codex / gemini 도 상태창에 표시 (선택)

같은 `pane-status.ps1` 을 재사용합니다. 각 도구 설정에 hook 추가:

- **codex** — `~\.codex\config.toml` 끝에 추가 후, 새 codex 세션에서 `/hooks` 로 **신뢰 승인 1회**:
  ```toml
  [[hooks.UserPromptSubmit]]
  [[hooks.UserPromptSubmit.hooks]]
  type = "command"
  command = "pwsh -NoProfile -File <홈>/.claude/hooks/pane-status.ps1 -Hook -State working -Tool codex"
  timeout = 10
  # Stop→idle, SessionStart(matcher \"startup|resume|clear|compact\")→start, PermissionRequest(matcher \".*\")→attention 도 같은 형식으로
  ```
- **gemini** — `~\.gemini\settings.json` 의 `"hooks"` 에 병합(재시작만):
  ```json
  "BeforeAgent":  [ { "matcher": "*", "hooks": [ { "type": "command", "command": "pwsh -NoProfile -File <홈>/.claude/hooks/pane-status.ps1 -Hook -State working -Tool gemini", "timeout": 10000 } ] } ],
  "AfterAgent":   [ { "matcher": "*", "hooks": [ { "type": "command", "command": "pwsh -NoProfile -File <홈>/.claude/hooks/pane-status.ps1 -Hook -State idle -Tool gemini", "timeout": 10000 } ] } ]
  ```
  (`<홈>` = `$env:USERPROFILE` 의 슬래시 경로, 예 `C:/Users/이름`.)

---

## 환경변수(선택)

- `PANE_STATUS_PATH=leaf|home|full` — 상태줄 폴더 표기(기본 full=절대경로).
- `PANE_STATUS_TINT=1` — Zellij 작업중 패널 배경 틴트.

## 제거

```powershell
pwsh -ExecutionPolicy Bypass -File .\install.ps1 -Uninstall
```

---

## 동작 원리 (요약)

- AI 라이프사이클 **hook** 이 상태(작업중/대기/확인) + 폴더 + 작업라벨을 `%TEMP%\claude-pane-status\<키>.json` 에 기록.
- 같은 패널의 모든 프로세스가 공유하는 키(`WT_SESSION` 또는 `ZELLIJ_PANE_ID`)를 사용 → statusline·상태창·AI가 같은 레코드를 가리킴.
- **statusLine** 은 그 레코드 + git/.git HEAD + 사용량(JSON)을 읽어 두 줄로 렌더.
- **aistatus** 는 그 레코드들을 2초마다 폴링해 표로 표시.
- 설계 상세: Obsidian Vault `01_projects/terminal-pane-labeling/setup-reproduction-guide.md`.
