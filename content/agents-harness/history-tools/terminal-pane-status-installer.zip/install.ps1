#requires -Version 7
<#
====================================================================
  AI 터미널 패널 상태 시스템 — 원클릭 설치
  분할 터미널에서 각 패널이 "어느 폴더 · 무슨 작업 · 작업중인지"를
  Claude 하단 상태줄 + aistatus 상태창으로 보여준다.
--------------------------------------------------------------------
  사용:
     pwsh -ExecutionPolicy Bypass -File .\install.ps1
  옵션:
     -NoZellij     Zellij 설정 건너뛰기
     -Uninstall    설치 되돌리기(.bak 가 있으면 복원, 스크립트 삭제)
  필수: Windows + PowerShell 7(pwsh) + Windows Terminal + Claude Code
  선택: Zellij(색 라벨), codex / gemini (README 참고)
  안전: settings.json / $PROFILE / CLAUDE.md 는 .bak 백업 후 '병합'(덮어쓰기 아님).
====================================================================
#>
param([switch]$NoZellij, [switch]$Uninstall)
$ErrorActionPreference = 'Stop'
$src = Join-Path $PSScriptRoot 'files'
$h   = $env:USERPROFILE
$hs  = ($h -replace '\\', '/')          # 명령 문자열용 슬래시 경로(사용자명 자동 적응)
function Say($m, $c = 'Gray') { Write-Host $m -ForegroundColor $c }

# ───────────────────────── 제거 ─────────────────────────
if ($Uninstall) {
    Say "▶ 제거(되돌리기)" Yellow
    foreach ($f in @("$h\.local\bin\pane-workspace.ps1", "$h\.claude\hooks\pane-status.ps1", "$h\.claude\hooks\claude-statusline.ps1", "$h\.claude\hooks\ai-dashboard.ps1")) {
        if (Test-Path $f) { Remove-Item $f -Force; Say "  - 삭제 $f" }
    }
    foreach ($b in @("$h\.claude\settings.json", "$PROFILE", "$h\.claude\CLAUDE.md")) {
        if (Test-Path "$b.bak-paneinstall") { Copy-Item "$b.bak-paneinstall" $b -Force; Say "  - 복원 $b (.bak)" }
    }
    if (Test-Path "$env:TEMP\claude-pane-status") { Remove-Item "$env:TEMP\claude-pane-status" -Recurse -Force }
    Say "✅ 제거 완료. settings.json/`$PROFILE/CLAUDE.md 의 hooks·라벨 규칙은 .bak 가 있던 경우만 복원됨(없으면 수동 제거)." Green
    return
}

Say "▶ AI 패널 상태 시스템 설치" Cyan
if (-not (Get-Command pwsh -EA SilentlyContinue)) { throw "PowerShell 7(pwsh) 필요. winget install Microsoft.PowerShell" }

# ── 1) 스크립트 4개 배치 ──
$map = @{
    'pane-workspace.ps1'    = "$h\.local\bin\pane-workspace.ps1"
    'pane-status.ps1'       = "$h\.claude\hooks\pane-status.ps1"
    'claude-statusline.ps1' = "$h\.claude\hooks\claude-statusline.ps1"
    'ai-dashboard.ps1'      = "$h\.claude\hooks\ai-dashboard.ps1"
}
foreach ($k in $map.Keys) {
    $dest = $map[$k]; New-Item -ItemType Directory -Force (Split-Path $dest) | Out-Null
    Copy-Item (Join-Path $src $k) $dest -Force
    Say "  ✓ $dest" Green
}

# ── 2) $PROFILE 에 dot-source (멱등) ──
if (-not (Test-Path $PROFILE)) { New-Item -ItemType File -Force $PROFILE | Out-Null }
if (-not (Select-String -LiteralPath $PROFILE -SimpleMatch 'pane-workspace.ps1' -Quiet)) {
    Copy-Item $PROFILE "$PROFILE.bak-paneinstall" -Force
    Add-Content -LiteralPath $PROFILE -Value "" -Encoding utf8
    Add-Content -LiteralPath $PROFILE -Value "# AI 분할 워크스페이스 헬퍼 (work/zwork/pane/label/panedemo/aistatus/wshelp)" -Encoding utf8
    Add-Content -LiteralPath $PROFILE -Value '. "$env:USERPROFILE\.local\bin\pane-workspace.ps1"' -Encoding utf8
    Say "  ✓ `$PROFILE 에 dot-source 추가" Green
}
else { Say "  • `$PROFILE 이미 설정됨(건너뜀)" DarkGray }

# ── 3) ~/.claude/settings.json 병합 (hooks + statusLine) ──
$sf = "$h\.claude\settings.json"
New-Item -ItemType Directory -Force (Split-Path $sf) | Out-Null
$s = if (Test-Path $sf) { Get-Content $sf -Raw | ConvertFrom-Json } else { [pscustomobject]@{} }
function HookEntry($state) { [pscustomobject]@{ hooks = @([pscustomobject]@{ type = 'command'; command = "pwsh -NoProfile -File $hs/.claude/hooks/pane-status.ps1 -Hook -State $state -Tool claude"; timeout = 5 }) } }
$hooks = [pscustomobject]@{
    UserPromptSubmit = @(HookEntry 'working'); Stop = @(HookEntry 'idle'); Notification = @(HookEntry 'attention')
    SessionStart = @(HookEntry 'start'); SessionEnd = @(HookEntry 'end')
}
$s | Add-Member -NotePropertyName hooks -NotePropertyValue $hooks -Force
$s | Add-Member -NotePropertyName statusLine -NotePropertyValue ([pscustomobject]@{ type = 'command'; command = "pwsh -NoProfile -File $hs/.claude/hooks/claude-statusline.ps1"; padding = 0 }) -Force
if (Test-Path $sf) { Copy-Item $sf "$sf.bak-paneinstall" -Force }
$s | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $sf -Encoding utf8
Say "  ✓ settings.json 병합 (hooks 5종 + statusLine)" Green

# ── 4) CLAUDE.md 에 AI 자동 라벨 규칙 (멱등) ──
$cm = "$h\.claude\CLAUDE.md"
if (-not (Test-Path $cm) -or -not (Select-String -LiteralPath $cm -SimpleMatch 'AI 작업 라벨 — 분할 터미널' -Quiet)) {
    if (Test-Path $cm) { Copy-Item $cm "$cm.bak-paneinstall" -Force } else { New-Item -ItemType File -Force $cm | Out-Null }
    $rule = @'

## AI 작업 라벨 — 분할 터미널 패널 표시
새 작업/요청을 시작할 때, 그 작업을 3~6단어로 요약한 라벨을 현재 패널에 1회 기록한다:
    pwsh -NoProfile -File "$env:USERPROFILE\.claude\hooks\pane-status.ps1" -Label "<짧은 작업명>" -Tool claude
- 작업 본질이 바뀌면 갱신. 사소한 후속/되묻기엔 갱신하지 않는다.
- 이 라벨은 Claude statusline(🤖)과 aistatus 상태창에 고정 표시된다. 사용자가 `label "..."`로 덮어쓸 수 있다.
'@
    Add-Content -LiteralPath $cm -Value $rule -Encoding utf8
    Say "  ✓ CLAUDE.md 에 AI 자동 라벨 규칙 추가" Green
}
else { Say "  • CLAUDE.md 규칙 이미 있음(건너뜀)" DarkGray }

# ── 5) (선택) Zellij ──
if (-not $NoZellij -and (Get-Command zellij -EA SilentlyContinue)) {
    $zc = Join-Path $env:APPDATA 'Zellij\config'
    New-Item -ItemType Directory -Force (Join-Path $zc 'layouts') | Out-Null
    Copy-Item (Join-Path $src 'zellij\config.kdl') (Join-Path $zc 'config.kdl') -Force
    Copy-Item (Join-Path $src 'zellij\ai4.kdl') (Join-Path $zc 'layouts\ai4.kdl') -Force
    Say "  ✓ Zellij 설정 설치 (zwork 4분할 색 라벨)" Green
}
else { Say "  • Zellij 건너뜀(선택). 색 라벨 원하면 winget install zellij 후 재실행" DarkGray }

Say ""
Say "✅ 설치 완료!" Green
Say "  1) 새 PowerShell 창 → wshelp / aistatus / label `"작업명`"" Gray
Say "  2) 새 claude 세션부터 하단 상태줄 + 자동 라벨 적용" Gray
Say "  3) codex/gemini 연동·사용법은 같은 폴더 README.md 참고" Gray
